TARGET_CLASSES = {
  0: "Normal",
  1: "Tuberculosis"
};